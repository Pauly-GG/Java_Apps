package com.example.guesstheceleb2023;

import android.graphics.Bitmap;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

import com.example.guesstheceleb2023.game.Game;
import com.example.guesstheceleb2023.game.Question;

public class GameUnitTest {

    @Test
    public void testCheckMethod() {
        Bitmap celebrityImage = null; // replace with actual Bitmap object

        String correctCelebrityName = "Tom Hanks";
        String incorrectCelebrityName = "Brad Pitt";

        String[] possibleNames = {correctCelebrityName, incorrectCelebrityName, "Leonardo DiCaprio", "Matt Damon"};

        // Create a new Question object
        Question question = new Question(correctCelebrityName, celebrityImage, possibleNames);

        // Test with the correct answer
        assertTrue(question.check(correctCelebrityName));

        // Test with the wrong answer
        assertFalse(question.check(incorrectCelebrityName));
    }

    @Test
    public void testGame() {
        Question[] questions = new Question[3];
        String[] answers = new String[]{"bob", "jane", "harry"};
        for (int i = 0; i < 3; ++i) {
            questions[i] = new Question(answers[i], null, answers);
        }
        Game game = new Game(questions);

        while (!game.isGameOver()) {
            Question question = game.next();
            game.updateScore(question.check("bob"));
        }
        assertEquals("Score 1/3", game.getScore());
    }
}
