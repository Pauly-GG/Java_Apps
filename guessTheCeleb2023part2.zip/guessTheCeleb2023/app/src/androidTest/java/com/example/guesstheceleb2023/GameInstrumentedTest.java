package com.example.guesstheceleb2023;

import android.content.Context;
import android.content.res.AssetManager;

import androidx.test.platform.app.InstrumentationRegistry;

import com.example.guesstheceleb2023.game.CelebrityManager;
import com.example.guesstheceleb2023.game.Difficulty;
import com.example.guesstheceleb2023.game.Game;
import com.example.guesstheceleb2023.game.GameBuilder;
import com.example.guesstheceleb2023.game.Question;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class GameInstrumentedTest {

    @Test
    public void testGameBuilder() {
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        AssetManager assetManager = context.getAssets();
        CelebrityManager celebrityManager = new CelebrityManager(assetManager, "celebs");

        GameBuilder gameBuilder = new GameBuilder(celebrityManager);
        Game game = gameBuilder.create(Difficulty.EASY);

        int correctlyAnswered = 0;
        loop: while (!game.isGameOver()) {
            Question question = game.next();
            for (int i = 0; i < celebrityManager.count(); ++i) {
                if (question.check(celebrityManager.getName(i))) {
                    correctlyAnswered++;
                    continue loop;
                }
            }
            fail("Didn't answer question correctly");
        }
        assertEquals(game.count(), correctlyAnswered);
    }
}
