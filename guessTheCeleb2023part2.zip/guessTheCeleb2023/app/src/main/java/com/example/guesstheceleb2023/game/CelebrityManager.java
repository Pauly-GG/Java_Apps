package com.example.guesstheceleb2023.game;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.IOException;
import java.io.InputStream;

public class CelebrityManager {
    public String assetPath;
    public String[] imageNames;
    public AssetManager assetManager;

    public CelebrityManager(AssetManager assetManager2, String assetPath2) {
        this.assetPath = assetPath2;
        this.assetManager = assetManager2;
        try {
            imageNames = assetManager.list(assetPath);
        } catch (IOException e) {
            imageNames = null;
        }
    }

    Bitmap get(int i) {
        InputStream stream = null;
        try {
            stream = assetManager.open(
                    assetPath + "/" + imageNames[i]);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Bitmap bitmap = BitmapFactory.decodeStream(stream);
        return bitmap;
    }

    public String getName(int i) {
        if (imageNames != null && i >= 0 && i < imageNames.length) {
            return imageNames[i].substring(0, imageNames[i].lastIndexOf('.'));
        } else {
            return null;
        }
    }

    public int count() {
        if (imageNames != null) {
            return imageNames.length;
        } else {
            return 0;
        }
    }
}
