package com.example.guesstheceleb2023;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;

import com.example.guesstheceleb2023.game.CelebrityManager;
import com.example.guesstheceleb2023.game.Difficulty;
import com.example.guesstheceleb2023.game.Game;
import com.example.guesstheceleb2023.game.GameBuilder;
import com.example.guesstheceleb2023.game.State;
import com.example.guesstheceleb2023.game.StateListener;

import java.io.IOException;
import java.util.Arrays;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements StateListener {

    private GameFragment gameFragment;
    private QuestionFragment questionFragment;
    private StatusFragment statusFragment;
    private CelebrityManager imageManager;
    private boolean isLargeScreen;
    private GameBuilder gameBuilder; // Assuming you have a GameBuilder class.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Use the FragmentManager to find the fragments
        FragmentManager fragmentManager = getSupportFragmentManager();
        gameFragment = (GameFragment) fragmentManager.findFragmentById(R.id.game_fragment);

        // On a large screen, the other fragments should also be present
        Fragment questionFragmentTemp = fragmentManager.findFragmentById(R.id.question_Fragment);
        Fragment statusFragmentTemp = fragmentManager.findFragmentById(R.id.status_fragment);

        if (questionFragmentTemp != null && statusFragmentTemp != null) {
            // We're on a large screen
            questionFragment = (QuestionFragment) questionFragmentTemp;
            statusFragment = (StatusFragment) statusFragmentTemp;
            isLargeScreen = true;
        } else {
            // We're on a normal screen
            isLargeScreen = false;
        }

        AssetManager manager = getAssets();
        try {
            String[] names = manager.list("celebs");
            System.out.println(Arrays.toString(names));
            imageManager = new CelebrityManager(manager, "celebs");
            gameBuilder = new GameBuilder(imageManager); // assuming your GameBuilder requires a CelebrityManager
        } catch (IOException e) {
            System.out.println("failed ....");
        }
    }

    @Override
    public void onUpdate(State state) {
        Difficulty level = gameFragment.getLevel();
        String text = String.format(Locale.getDefault(),
                "state: %s level: %s", state, level);
        Log.i("MainActivity", text);

        if (isLargeScreen) {
            switch (state) {
                case START_GAME:
                    Game game = gameBuilder.create(level);
                    questionFragment.setGame(game);
                    break;
                // You might want to handle other states here
            }
        } else {
            // Handle state changes for small screen here
        }
    }
}
