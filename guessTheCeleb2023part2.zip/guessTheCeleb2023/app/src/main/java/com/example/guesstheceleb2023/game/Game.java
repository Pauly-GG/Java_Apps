package com.example.guesstheceleb2023.game;

public class Game {
    private Question[] questions;
    private int currentQuestionIndex = 0;
    private int score = 0;

    public Game(Question[] questions) {
        this.questions = questions;
    }

    public boolean isGameOver() {
        return currentQuestionIndex >= questions.length;
    }

    public Question next() {
        if (isGameOver()) {
            return null;
        } else {
            return questions[currentQuestionIndex++];
        }
    }

    public void updateScore(boolean isCorrect) {
        if (isCorrect) {
            score++;
        }
    }

    public String getScore() {
        return "Score " + score + "/" + questions.length;
    }

    public Object count() {
        return null;
    }
}
