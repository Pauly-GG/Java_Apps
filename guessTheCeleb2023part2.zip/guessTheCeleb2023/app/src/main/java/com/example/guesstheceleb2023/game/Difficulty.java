package com.example.guesstheceleb2023.game;

public enum Difficulty {
    EASY,
    MEDIUM,
    HARD,
    EXPERT
}

