package com.example.guesstheceleb2023.game;

public enum State {
    START_GAME, CONTINUE_GAME, GAME_OVER
}
