package com.example.guesstheceleb2023.game;

import android.util.Log;
import com.example.guesstheceleb2023.game.CelebrityManager;
import com.example.guesstheceleb2023.game.Difficulty;
import com.example.guesstheceleb2023.game.Game;
import com.example.guesstheceleb2023.game.Question;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class GameBuilder {

    private CelebrityManager celebrityManager;
    private static final String TAG = GameBuilder.class.getSimpleName();

    public GameBuilder(CelebrityManager celebrityManager) {
        this.celebrityManager = celebrityManager;
    }

    public Game create(Difficulty difficulty) {
        int N;
        switch (difficulty) {
            case MEDIUM:
                N = 6;
                break;
            case HARD:
                N = 12;
                break;
            case EXPERT:
                N = 24;
                break;
            default: // EASY
                N = 3;
                break;
        }

        Set<String> celebritySet = new HashSet<>();
        while (celebritySet.size() < N) {
            String randomCelebrity = celebrityManager.getName((int)(Math.random()*celebrityManager.count()));
            celebritySet.add(randomCelebrity);
        }

        String[] celebrities = celebritySet.toArray(new String[0]);

        Question[] questions = new Question[N];
        for (int i = 0; i < N; i++) {
            Log.i(TAG, "Creating question for celebrity: " + celebrities[i]);
            questions[i] = new Question(celebrities[i], celebrityManager.get(i), celebrities);
        }

        Collections.shuffle(Arrays.asList(questions));
        return new Game(questions);
    }
}
