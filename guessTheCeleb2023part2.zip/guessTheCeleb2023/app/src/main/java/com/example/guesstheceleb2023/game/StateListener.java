package com.example.guesstheceleb2023.game;

public interface StateListener {
    void onUpdate(State state);
}
