package com.example.guesstheceleb2023;

import org.junit.Test;
import static org.junit.Assert.*;

import com.example.guesstheceleb2023.game.Game;
import com.example.guesstheceleb2023.game.Question;

public class GameUnitTest {
    @Test
    public void testGame() {
        Question[] questions = new Question[3];
        String[] answers = new String[] {"bob", "jane", "harry"};
        for (int i = 0; i < 3; ++i) {
            questions[i] = new Question(answers[i], null, null);
        }
        Game game = new Game(questions);

        while (!game.isGameOver()) {
            Question question = game.next();
            game.updateScore(question.check("bob"));
        }
        assertEquals("Score: 1/3", game.getScore());
    }
}
