package com.example.guesstheceleb2023;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.IOException;
import java.io.InputStream;

public class MyImageManager {
    private String assetPath;
    private String[] imageNames;
    private AssetManager assetManager;

    MyImageManager(AssetManager assetManager2, String assetPath2) {
        this.assetPath = assetPath2;
        this.assetManager = assetManager2;
        try {
            imageNames = assetManager.list(assetPath);
        } catch (IOException e) {
            imageNames = null;
        }
    }

    Bitmap get(int i) {
        InputStream stream = null;
        try {
            stream = assetManager.open(
                    assetPath + "/" + imageNames[i]);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Bitmap bitmap = BitmapFactory.decodeStream(stream);
        return bitmap;
    }
}
