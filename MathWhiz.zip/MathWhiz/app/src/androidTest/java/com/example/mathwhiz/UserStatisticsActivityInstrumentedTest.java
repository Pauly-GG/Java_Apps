package com.example.mathwhiz;

import static androidx.test.core.app.ActivityScenario.launch;

import static org.junit.Assert.assertEquals;

import android.view.View;
import android.widget.TextView;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.MediumTest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@MediumTest
@RunWith(AndroidJUnit4.class)
public class UserStatisticsActivityInstrumentedTest {

    private ActivityScenario<UserStatisticsActivity> scenario;

    @Before
    public void setUp() {
        scenario = launch(UserStatisticsActivity.class);
    }

    @Test
    public void testDefaultTextViewValues() {
        scenario.onActivity(activity -> {
            TextView totalQuestionsTextView = activity.findViewById(R.id.total_questions_text);
            TextView highScoreTextView = activity.findViewById(R.id.high_score_text_view);

            // Check if the TextViews display the default values
            assertEquals("Total Questions: 0", totalQuestionsTextView.getText().toString());
            assertEquals("High Score: 0/10", highScoreTextView.getText().toString());
        });
    }

    @Test
    public void testActivity_inView() {
        scenario.onActivity(activity -> {
            // Check if the right views are displayed
            assertEquals(View.VISIBLE, activity.findViewById(R.id.total_questions_text).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.high_score_text_view).getVisibility());
        });
    }
}
