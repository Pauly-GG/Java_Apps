package com.example.mathwhiz;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.MediumTest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.core.app.ActivityScenario.launch;
import static org.junit.Assert.assertEquals;

import android.view.View;

@MediumTest
@RunWith(AndroidJUnit4.class)
public class EndGameActivityInstrumentedTest {

    private ActivityScenario<EndGameActivity> scenario;

    @Before
    public void setUp() {
        scenario = launch(EndGameActivity.class);
    }

    @Test
    public void testActivity_inView() {
        scenario.onActivity(activity -> {
            // Check if the right views are displayed
            assertEquals(View.VISIBLE, activity.findViewById(R.id.score_text_view).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.main_menu_button).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.shareButton).getVisibility());
        });
    }

    @Test
    public void testActivity_inStartedLifecycle() {
        scenario.moveToState(Lifecycle.State.STARTED);
        assertEquals(Lifecycle.State.STARTED, scenario.getState());
    }

    @Test
    public void testActivity_inResumedLifecycle() {
        scenario.moveToState(Lifecycle.State.RESUMED);
        assertEquals(Lifecycle.State.RESUMED, scenario.getState());
    }
}
