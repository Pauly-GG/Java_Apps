package com.example.mathwhiz;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class QuestionBank {

    private final Random random = new Random();

    // This method generates a question and returns it along with the answer choices
    public Question generateQuestion(int difficultyLevel) {
        int number1 = random.nextInt(10) + 1; // generates a random number between 1 and 10
        int number2 = random.nextInt(10) + 1; // generates a random number between 1 and 10
        int answer = number1 + number2;
        String questionText = "What is " + number1 + " + " + number2 + "?";

        List<Integer> answerChoices = new ArrayList<>();
        answerChoices.add(answer); // add the correct answer first

        // add incorrect answers based on difficulty level
        while (answerChoices.size() < difficultyLevel + 2) {
            int incorrectAnswer = random.nextInt(20) + 1; // generates a random number between 1 and 20

            // ensure the incorrect answer is not the same as the correct answer
            if (incorrectAnswer != answer) {
                answerChoices.add(incorrectAnswer);
            }
        }
            // Shuffle the answer choices
        Collections.shuffle(answerChoices);
        return new Question(questionText, answer, answerChoices);
    }
}
