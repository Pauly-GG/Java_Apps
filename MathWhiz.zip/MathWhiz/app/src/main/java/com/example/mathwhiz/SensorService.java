package com.example.mathwhiz;

import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.IBinder;
import android.util.Log;

public class SensorService extends Service {
    public static final String ACTION_SHAKE_DETECTED = "com.yourdomain.app.ACTION_SHAKE_DETECTED";

    private SensorManager mSensorManager;
    private ShakeDetector mShakeDetector;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Get a reference to the Sensor Service
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mShakeDetector = new ShakeDetector();

        // Get the device's accelerometer
        Sensor accelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mSensorManager.registerListener(mShakeDetector, accelerometer, SensorManager.SENSOR_DELAY_UI);

        // Set a listener on the ShakeDetector
        mShakeDetector.setOnShakeListener(new ShakeDetector.OnShakeListener() {

            @Override
            public void onShake() {
                // Log a message when the device is shaken
                Log.i("ShakeDetector", "Device was shaken!");
                // Create and send a broadcast when the device is shaken
                Intent shakeIntent = new Intent(ACTION_SHAKE_DETECTED);
                sendBroadcast(shakeIntent);
            }
        });

        // Return START_STICKY to let the system know to recreate the service after it has enough memory and after it's been killed.
        return START_STICKY;
    }

    // Called when the service is destroyed
    @Override
    public void onDestroy() {
        super.onDestroy();
        mSensorManager.unregisterListener(mShakeDetector);
    }
}
