package com.example.mathwhiz;

import java.util.List;

public class Question {

    private final String questionText;
    private final int answer;
    private final List<Integer> answerChoices;

    public Question(String questionText, int answer, List<Integer> answerChoices) {
        this.questionText = questionText;
        this.answer = answer;
        this.answerChoices = answerChoices;
    }

    public String getQuestionText() {
        return questionText;
    }

    public int getAnswer() {
        return answer;
    }

    public List<Integer> getAnswerChoices() {
        return answerChoices;
    }
}
