package com.example.mathwhiz;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityScreenActivity extends AppCompatActivity {

    private TextView questionTextView;
    private TextView scoreTextView;
    private RadioGroup answersRadioGroup;
    private Question currentQuestion;
    private int score = 0;
    private int totalAnsweredQuestions = 0;
    private static final int TOTAL_QUESTIONS = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the layout for this activity
        setContentView(R.layout.activity_screen);

        questionTextView = findViewById(R.id.question_text);
        answersRadioGroup = findViewById(R.id.answers_radio_group);
        scoreTextView = findViewById(R.id.score_text_view);
        Button checkAnswerButton = findViewById(R.id.check_answer_button);

        // Set click listener for the "Check answer" button
        checkAnswerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });

        setUpQuestionAndAnswers();
        updateScoreText(); // Update score display after scoreTextView initialization
    }

    private void setUpQuestionAndAnswers() {
        answersRadioGroup.clearCheck();

        // Instantiate a QuestionBank, which will generate our questions
        QuestionBank questionBank = new QuestionBank();

        // Get the current difficulty level from settings
        int difficultyLevel = SettingsActivity.getDifficultyLevel(this);

        // Generate a new question with the current difficulty level
        currentQuestion = questionBank.generateQuestion(difficultyLevel);

        // Set the question text in the TextView
        questionTextView.setText(currentQuestion.getQuestionText());

        // Remove all RadioButtons from the RadioGroup before adding new ones
        answersRadioGroup.removeAllViews();

        // Loop through the answer choices of the current question, create a RadioButton for each, and add it to the RadioGroup
        for (int i = 0; i < currentQuestion.getAnswerChoices().size(); i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(String.valueOf(currentQuestion.getAnswerChoices().get(i)));
            radioButton.setId(i);
            answersRadioGroup.addView(radioButton);
        }
    }


    private void checkAnswer() {
        int selectedAnswerId = answersRadioGroup.getCheckedRadioButtonId();

        // If no RadioButton is selected, show a Toast and return
        if (selectedAnswerId == -1) {
            Toast.makeText(this, "Please select an answer.", Toast.LENGTH_SHORT).show();
            return;
        }

        RadioButton selectedRadioButton = findViewById(selectedAnswerId);
        int selectedAnswer = Integer.parseInt(selectedRadioButton.getText().toString());

        totalAnsweredQuestions++;

        // If the selected answer is correct, increment the score and show a "Correct!" Toast
        if (selectedAnswer == currentQuestion.getAnswer()) {
            score++;
            Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
            updateScoreText();  // update the score display
        } else { // If the selected answer is incorrect, show an "Incorrect." Toast
            Toast.makeText(this, "Incorrect.", Toast.LENGTH_SHORT).show();
        }

        if (totalAnsweredQuestions == TOTAL_QUESTIONS) {
            endGame();
        } else {
            setUpQuestionAndAnswers();
        }
    }

    private void endGame() {
        Intent intent = new Intent(ActivityScreenActivity.this, EndGameActivity.class);
        intent.putExtra("SCORE", score);  // Pass the final score to EndGameActivity
        startActivity(intent);
        finish();  // Finish ActivityScreenActivity so the user can't go back to it
    }

    @SuppressLint("DefaultLocale")
    private void updateScoreText() {
        scoreTextView.setText(String.format("Score: %d/10", score));
    }
}
