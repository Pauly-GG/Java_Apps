package com.example.mathwhiz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;

public class LandingPageActivity extends AppCompatActivity {

    private BroadcastReceiver mShakeDetectorReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the layout for this activity
        setContentView(R.layout.activity_landing);

        // Start SensorService here
        Intent sensorServiceIntent = new Intent(this, SensorService.class);
        startService(sensorServiceIntent);

        // Get references to the navigation buttons
        Button activityButton = findViewById(R.id.btn_activity);
        Button settingsButton = findViewById(R.id.btn_settings);
        Button statisticsButton = findViewById(R.id.btn_statistics);

        // Set up click listeners for the buttons
        activityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the ActivityScreen
                Intent intent = new Intent(LandingPageActivity.this, ActivityScreenActivity.class);
                startActivity(intent);
            }
        });

        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the SettingsScreen
                Intent intent = new Intent(LandingPageActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        statisticsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the UserStatisticsScreen
                Intent intent = new Intent(LandingPageActivity.this, UserStatisticsActivity.class);
                startActivity(intent);
            }
        });

        // Create the BroadcastReceiver
        mShakeDetectorReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (SensorService.ACTION_SHAKE_DETECTED.equals(intent.getAction())) {
                    // Shake detected, close the application
                    System.exit(0);
                }
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Register the BroadcastReceiver when the activity is visible
        registerReceiver(mShakeDetectorReceiver, new IntentFilter(SensorService.ACTION_SHAKE_DETECTED));
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Unregister the BroadcastReceiver when the activity is not visible
        unregisterReceiver(mShakeDetectorReceiver);
    }
}
