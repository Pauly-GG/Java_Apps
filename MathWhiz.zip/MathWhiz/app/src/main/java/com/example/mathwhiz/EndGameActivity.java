package com.example.mathwhiz;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EndGameActivity extends AppCompatActivity {

    private static final int TOTAL_QUESTIONS = 10;

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the layout for this activity
        setContentView(R.layout.activity_end_game);

        TextView scoreTextView = findViewById(R.id.score_text_view);

        // Retrieve the score from the previous activity
        Intent intent = getIntent();
        int score = intent.getIntExtra("SCORE", 0);

        // Set the score text
        scoreTextView.setText(String.format("You scored: %d/%d", score, TOTAL_QUESTIONS));

        // Retrieve the shared preferences
        SharedPreferences sharedPreferences = getSharedPreferences("MATH_WHIZ_PREFS", MODE_PRIVATE);

        // Retrieve the current high score
        int highScore = sharedPreferences.getInt("HIGH_SCORE", 0);

        // Compare the current score with the high score
        if (score > highScore) {
            // Update the high score
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt("HIGH_SCORE", score);
            editor.apply();
        }

        // Update total questions answered
        int totalAnsweredQuestions = sharedPreferences.getInt("TOTAL_ANSWERED_QUESTIONS", 0);
        totalAnsweredQuestions += TOTAL_QUESTIONS;  // Increment by the number of questions in a game

        // Save the updated total questions answered
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("TOTAL_ANSWERED_QUESTIONS", totalAnsweredQuestions);
        editor.apply();

        // Set up the Main Menu button
        Button mainMenuButton = findViewById(R.id.main_menu_button);
        mainMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start MainActivity
                Intent intent = new Intent(EndGameActivity.this, MainActivity.class);
                startActivity(intent);
                // Optionally, if you want to finish the current activity:
                finish();
            }
        });

        // Set up the share button
        Button shareButton = findViewById(R.id.shareButton);
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("EndGameActivity", "Share button clicked"); // Add this line
                shareScore(score);
            }
        });
    }

    private void shareScore(int score) {
        // calculate score to share
        String message = "I scored " + score + "/10 on Math Whiz!";

        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, message);
        sendIntent.setType("text/plain");

        // starts an activity to share the score
        Intent shareIntent = Intent.createChooser(sendIntent, null);
        startActivity(shareIntent);
    }
}

