package com.example.mathwhiz;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mathwhiz.LandingPageActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the layout for this activity
        setContentView(R.layout.activity_main);

        // Create an Intent to start LandingPageActivity
        Intent intent = new Intent(this, LandingPageActivity.class);
        startActivity(intent);
    }
}
