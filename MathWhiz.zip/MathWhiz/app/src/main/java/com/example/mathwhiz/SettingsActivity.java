package com.example.mathwhiz;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class SettingsActivity extends AppCompatActivity {

    private SeekBar difficultySeekBar;
    private TextView difficultyLevelTextView;
    private static final String SHARED_PREFERENCES_NAME = "Settings";
    private static final String DIFFICULTY_LEVEL_KEY = "difficultyLevel";
    private static final String NIGHT_MODE_KEY = "NightMode";
    private BroadcastReceiver mShakeDetectorReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get the stored NightMode state
        boolean isNightModeEnabled = getNightModeState(this);

        // Check current night mode and only set new one if it's different
        int currentNightMode = AppCompatDelegate.getDefaultNightMode();
        if (isNightModeEnabled && currentNightMode != AppCompatDelegate.MODE_NIGHT_YES) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else if (!isNightModeEnabled && currentNightMode != AppCompatDelegate.MODE_NIGHT_NO) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        // Set the layout for this activity
        setContentView(R.layout.activity_settings);

        // Find and initialize UI components
        difficultySeekBar = findViewById(R.id.difficulty_seek_bar);
        difficultyLevelTextView = findViewById(R.id.difficulty_level_text_view);
        Button backButton = findViewById(R.id.back_button);
        @SuppressLint("UseSwitchCompatOrMaterialCode") Switch darkModeSwitch = findViewById(R.id.dark_mode_switch);

        // Set initial state for DarkMode switch
        darkModeSwitch.setChecked(isNightModeEnabled);

        // Get and set the saved difficulty level
        int savedDifficultyLevel = getDifficultyLevel(this);
        difficultySeekBar.setProgress(savedDifficultyLevel);
        updateDifficultyLevelTextView(savedDifficultyLevel);

        // Set listener for changes in SeekBar
        difficultySeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Update difficulty level text view and save settings
                updateDifficultyLevelTextView(progress);
                saveSettings();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Initialize BroadcastReceiver for shake detection
        mShakeDetectorReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (SensorService.ACTION_SHAKE_DETECTED.equals(intent.getAction())) {
                    // If shake is detected, close the application
                    System.exit(0);
                }
            }
        };

        // Set listeners for DarkMode switch and back button
        darkModeSwitch.setOnClickListener(v -> {
            boolean isChecked = darkModeSwitch.isChecked();
            saveNightModeState(isChecked);  // Save Nightmode state
            // Set NightMode according to the new state
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
        });
        backButton.setOnClickListener(v -> finish()); // Finish activity on back button click
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Register the BroadcastReceiver when the activity is visible
        registerReceiver(mShakeDetectorReceiver, new IntentFilter(SensorService.ACTION_SHAKE_DETECTED));
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Unregister the BroadcastReceiver when the activity is not visible
        unregisterReceiver(mShakeDetectorReceiver);
    }

    @SuppressLint("SetTextI18n")
    private void updateDifficultyLevelTextView(int progress) {
        // Update the difficulty level text view according to the progress
        switch (progress) {
            case 0:
                difficultyLevelTextView.setText("Easy");
                break;
            case 1:
                difficultyLevelTextView.setText("Medium");
                break;
            case 2:
                difficultyLevelTextView.setText("Hard");
                break;
        }
    }

    // Save settings in SharedPreferences
    private void saveSettings() {
        SharedPreferences sharedPref = getSharedPreferences(SHARED_PREFERENCES_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(DIFFICULTY_LEVEL_KEY, difficultySeekBar.getProgress());
        editor.apply();

        Toast.makeText(this, "Settings saved.", Toast.LENGTH_SHORT).show();
    }

    // Save NightMode state in SharedPreferences
    private void saveNightModeState(boolean nightMode) {
        SharedPreferences sharedPref = getSharedPreferences(SHARED_PREFERENCES_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(NIGHT_MODE_KEY, nightMode);
        editor.apply();
    }

    // Get saved difficulty level from SharedPreferences
    public static int getDifficultyLevel(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getInt(DIFFICULTY_LEVEL_KEY, 0);
    }

    // Get saved NightMode state from SharedPreferences
    public static boolean getNightModeState(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(NIGHT_MODE_KEY, false);
    }
}
