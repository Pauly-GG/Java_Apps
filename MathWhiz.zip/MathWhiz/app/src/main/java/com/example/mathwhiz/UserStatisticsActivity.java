package com.example.mathwhiz;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class UserStatisticsActivity extends AppCompatActivity {

    private TextView highScoreTextView;
    private TextView totalQuestionsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_statistics);

        // Initialize TextViews by their ID in the layout
        highScoreTextView = findViewById(R.id.high_score_text_view);
        totalQuestionsTextView = findViewById(R.id.total_questions_text);
        Button backButton = findViewById(R.id.back_button);

        // Set click listener on the backButton
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // This will close the current activity and return to the previous one
            }
        });

        loadStatistics();
    }

    @SuppressLint("DefaultLocale")
    private void loadStatistics() {
        SharedPreferences sharedPreferences = getSharedPreferences("MATH_WHIZ_PREFS", MODE_PRIVATE);

        // If data is not present, set high score and total questions answered to 0
        int highScore = sharedPreferences.getInt("HIGH_SCORE", 0);
        int totalAnsweredQuestions = sharedPreferences.getInt("TOTAL_ANSWERED_QUESTIONS", 0);

        // Display high score and total questions answered in respective TextViews
        highScoreTextView.setText(String.format("High Score: %d/10", highScore));
        totalQuestionsTextView.setText(String.format("Total Questions: %d", totalAnsweredQuestions));
    }
}
