package com.example.mathwhiz;

import org.junit.Test;
import com.example.mathwhiz.EndGameActivity;

import static org.junit.Assert.*;

import android.content.Intent;
import android.widget.TextView;

import java.util.Arrays;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */

public class ExampleUnitTest {

    @Test
    public void testQuestion_isCorrect() {
        Question question = new Question("What is 1 + 1?", 2, Arrays.asList(2, 3, 4, 5));
        assertEquals("What is 1 + 1?", question.getQuestionText());
        assertEquals(2, question.getAnswer());
        assertEquals(Arrays.asList(2, 3, 4, 5), question.getAnswerChoices());
    }
}
