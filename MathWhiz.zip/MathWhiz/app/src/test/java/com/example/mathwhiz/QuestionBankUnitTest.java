package com.example.mathwhiz;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class QuestionBankUnitTest {

    @Test
    public void testGenerateQuestion_isCorrect() {
        QuestionBank questionBank = new QuestionBank();
        Question question = questionBank.generateQuestion(2);

        assertNotNull(question); // check that a question is generated

        // Check question text
        assertNotNull(question.getQuestionText());

        // Check that the correct answer is within the valid range of 1-20
        assertTrue(question.getAnswer() >= 1 && question.getAnswer() <= 20);

        // Check if the number of answer choices is correct based on the difficulty level
        assertEquals(4, question.getAnswerChoices().size());

        // Check if the correct answer is included in the answer choices
        assertTrue(question.getAnswerChoices().contains(question.getAnswer()));
    }
}
